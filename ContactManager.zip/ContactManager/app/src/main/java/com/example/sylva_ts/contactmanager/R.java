package com.example.sylva_ts.contactmanager;

/**
 * Created by Sylva-Ts on 2017-04-02.
 */

public final class R {
}
